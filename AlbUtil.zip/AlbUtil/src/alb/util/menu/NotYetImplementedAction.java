package alb.util.menu;



public class NotYetImplementedAction implements Action {

	@Override
	public void execute() {
		System.err.println("Not yet implemented option");
	}

}
