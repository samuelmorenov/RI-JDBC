package alb.util.linker;

public enum Multiplicity {
	ONE, 
	MANY
}
